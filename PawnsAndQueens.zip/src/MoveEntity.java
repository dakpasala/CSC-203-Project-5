import processing.core.PImage;

import java.util.List;
import java.util.function.BiPredicate;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Stream;

public abstract class MoveEntity extends ActiveEntity {

    public MoveEntity(String id,
                        Point position, int actionPeriod, int animationPeriod, List<PImage> images) {
        super(id, position, actionPeriod, animationPeriod, images);

    }
    public Point nextPosition(
            WorldModel world, Point destPos)
    {
        PathingStrategy strat = new AStarPathingStrategy();

        Point start = super.getPosition();
        Point end = destPos;
        Predicate<Point> canPassThrough = p -> !(world.isOccupied(p) && _nextPositionHelper(p, world)) && world.withinBounds(p);
        BiPredicate<Point, Point> withinReach = MoveEntity::adjacent;
        Function<Point, Stream<Point>> potentialNeighbors = PathingStrategy.CARDINAL_NEIGHBORS;
        List<Point> path = strat.computePath(start, end, canPassThrough, withinReach, potentialNeighbors);
        if (path.isEmpty()) {
            return start;
        }
        return path.get(0);
    }

    protected abstract boolean _nextPositionHelper(Point newPos, WorldModel world);

    abstract boolean moveTo(WorldModel world,
                   Entity target,
                   EventScheduler scheduler);


    public static boolean adjacent(Point p1, Point p2) {
        return (p1.x == p2.x && Math.abs(p1.y - p2.y) == 1) || (p1.y == p2.y
                && Math.abs(p1.x - p2.x) == 1);
    }

}