public abstract class Action {
    abstract void executeAction(EventScheduler scheduler);
}