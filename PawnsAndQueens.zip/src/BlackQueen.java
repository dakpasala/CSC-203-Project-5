import processing.core.PImage;

import java.util.List;
import java.util.Optional;
import java.util.Random;

public class BlackQueen extends Queen {
    public BlackQueen(String id, Point position, int actionPeriod, int animationPeriod, List<PImage> images) {
        super(id, position, actionPeriod, animationPeriod, images);
    }

}
